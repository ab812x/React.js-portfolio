import "./App.css";
import { useEffect } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Header from "./components/Header";
import ProgressBar from "./components/ProgressBar";
import HeroSection from "./components/HeroSection";
import AboutSection from "./components/AboutSection";
import ProjectSection from "./components/ProjectSection";
import ExperienceSection from "./components/ExperienceSection";
import ContactSection from "./components/ContactSection";
import Footer from "./components/Footer";
import CustomCursor from "./components/CustomCursor";

gsap.registerPlugin(ScrollTrigger);

function App() {
  // Refresh ScrollTrigger after all components mount
  useEffect(() => {
    ScrollTrigger.refresh();
  }, []);

  return (
    <>
      <CustomCursor />
      <Header />
      <ProgressBar />
      <HeroSection />
      <AboutSection />
      <ProjectSection />
      <ExperienceSection />
      <ContactSection />
      <Footer />
    </>
  );
}

export default App;
