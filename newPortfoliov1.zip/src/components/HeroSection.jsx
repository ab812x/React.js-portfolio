// npm install gsap @gsap/react
import { motion } from "framer-motion";
import Spline from "@splinetool/react-spline";
import { useGSAP } from "@gsap/react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useRef } from "react";

const HeroSection = () => {
  const textRef = useRef(null);

  useGSAP(() => {
    gsap.to(textRef.current, {
      y: -120,
      opacity: 0.3,
      ease: "none",
      scrollTrigger: {
        trigger: "#home",
        start: "top top",
        end: "bottom top",
        scrub: 1.5,
      },
    });
  }, []);

  return (
    <section id="home" className="h-screen bg-linear-to-b from-violet-900 to-black flex xl:flex-row flex-col-reverse items-center justify-between lg:px-24 px-10 relative overflow-hidden">
      {/* left section */}
      <div ref={textRef} className="z-40 xl:mb-0 mb-[20%]">
        <motion.h1
          initial={{ opacity: 0, y: 80 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            type: "spring",
            stiffness: 40,
            damping: 25,
            delay: 1.3,
            duration: 1.5,
          }}
          data-cursor="text"
          className="text-4xl md:text-6xl lg:text-7xl font-bold z-10 mb-6"
        >
          Turning Ideas Into High-Performance Web Apps
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 80 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            type: "spring",
            stiffness: 40,
            damping: 25,
            delay: 1.8,
            duration: 1.5,
          }}
          data-cursor="text"
          className="text-lg md:text-xl lg:text-xl text-purple-200 max-w-2xl"
        >
          I help businesses and individuals bring their ideas to life through
          fast, responsive, and visually engaging web applications using modern
          frontend technologies. <br />
          Based in Egypt • Available for freelance work
        </motion.p>
      </div>

      {/* Right section */}
      <Spline scene="https://prod.spline.design/Px1fdImyXiaIsixY/scene.splinecode" />
    </section>
  );
};

export default HeroSection;
