import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

/**
 * ── CustomCursor ──
 *
 * A frosted-glass circle cursor that displays monospaced function calls
 * based on what the user is hovering — like an active console overlay.
 *
 * ── USAGE IN OTHER COMPONENTS ──
 * Add a data-cursor attribute to any element to change the cursor text:
 *
 *   <a data-cursor="social" href="...">GitHub</a>
 *   <button data-cursor="button">Hire Me</button>
 *   <div data-cursor="project">Project Card</div>
 *   <a data-cursor="link" href="...">Live Demo</a>
 *   <p data-cursor="text">About paragraph</p>
 *
 * Cursor state mapping:
 *   default (nothing)   → idle()
 *   data-cursor="project" → render()
 *   data-cursor="social"  → connect()
 *   data-cursor="button"  → invoke()
 *   data-cursor="link"    → GET /
 *   data-cursor="text"    → read()
 */

const CURSOR_MAP = {
  project: "render()",
  social: "connect()",
  button: "invoke()",
  link: "GET /",
  text: "read()",
};

const DEFAULT_LABEL = "idle()";

const CustomCursor = () => {
  const [label, setLabel] = useState(DEFAULT_LABEL);
  const [cursorKey, setCursorKey] = useState(null); // raw data-cursor value
  const [visible, setVisible] = useState(false);
  const [isTouch, setIsTouch] = useState(false);

  const cursorX = useMotionValue(-100);
  const cursorY = useMotionValue(-100);

  const springX = useSpring(cursorX, { stiffness: 800, damping: 60, mass: 0.3 });
  const springY = useSpring(cursorY, { stiffness: 800, damping: 60, mass: 0.3 });

  useEffect(() => {
    // Detect touch-only devices
    if (typeof navigator !== "undefined" && navigator.maxTouchPoints > 0) {
      setIsTouch(true);
      return;
    }

    // Hide the system cursor globally
    const style = document.createElement("style");
    style.id = "custom-cursor-hide";
    style.textContent = "* { cursor: none !important; }";
    document.head.appendChild(style);

    const handleMouseMove = (e) => {
      cursorX.set(e.clientX);
      cursorY.set(e.clientY);
      if (!visible) setVisible(true);
    };

    const handleMouseOver = (e) => {
      const target = e.target;
      // Walk up from the hovered element to find the nearest data-cursor
      const cursorEl = target.closest("[data-cursor]");
      if (cursorEl) {
        const key = cursorEl.getAttribute("data-cursor");
        setCursorKey(key);
        setLabel(CURSOR_MAP[key] || DEFAULT_LABEL);
      } else {
        setCursorKey(null);
        setLabel(DEFAULT_LABEL);
      }
    };

    const handleMouseLeave = () => setVisible(false);
    const handleMouseEnter = () => setVisible(true);

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseover", handleMouseOver);
    document.documentElement.addEventListener("mouseleave", handleMouseLeave);
    document.documentElement.addEventListener("mouseenter", handleMouseEnter);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseover", handleMouseOver);
      document.documentElement.removeEventListener("mouseleave", handleMouseLeave);
      document.documentElement.removeEventListener("mouseenter", handleMouseEnter);
      // Restore the system cursor
      const existing = document.getElementById("custom-cursor-hide");
      if (existing) existing.remove();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Render nothing on touch devices
  if (isTouch) return null;

  const isButton = cursorKey === "button";

  return (
    <motion.div
      className="fixed top-0 left-0 z-[9999] pointer-events-none w-16 h-16 rounded-full bg-violet-600/20 backdrop-blur-sm border border-violet-500/40 flex items-center justify-center select-none"
      style={{
        x: springX,
        y: springY,
        translateX: "-50%",
        translateY: "-50%",
        boxShadow: "0 0 18px 4px rgba(139, 92, 246, 0.35)",
      }}
      animate={{
        opacity: visible ? 1 : 0,
        scale: isButton ? 1.15 : 1,
      }}
      transition={{
        opacity: { duration: 0.12 },
        scale: { type: "spring", stiffness: 300, damping: 25 },
      }}
    >
      <span className="font-mono text-[10px] font-medium text-white">
        {label}
      </span>
    </motion.div>
  );
};

export default CustomCursor;
