import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";

const LABEL_MAP = {
  button:  "execute()",
  link:    "GET()",
  project: "open()",
  social:  "connect()",
  text:    "read()",
};

const useCursor = () => {
  const dotRef   = useRef(null);
  const labelRef = useRef(null);
  const posRef   = useRef({ x: -100, y: -100 });
  const xTo      = useRef(null);
  const yTo      = useRef(null);

  const [label, setLabel]     = useState("");
  const [visible, setVisible] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isTouch, setIsTouch] = useState(false);

  useEffect(() => {
    if (navigator.maxTouchPoints > 0) {
      setIsTouch(true);
      return;
    }

    // Hide system cursor
    const styleEl = document.createElement("style");
    styleEl.id = "cursor-hide";
    styleEl.textContent = "*, *::before, *::after { cursor: none !important; }";
    document.head.appendChild(styleEl);

    // ── GSAP quickTo setup ────────────────────────────────
    // Only create after dotRef is confirmed mounted
    xTo.current = gsap.quickTo(dotRef.current, "x", {
      duration: 0.12,
      ease: "power3.out",
    });
    yTo.current = gsap.quickTo(dotRef.current, "y", {
      duration: 0.12,
      ease: "power3.out",
    });

    // ── MOUSE MOVE ────────────────────────────────────────
    const handleMouseMove = (e) => {
      posRef.current = { x: e.clientX, y: e.clientY };
      xTo.current(e.clientX);
      yTo.current(e.clientY);

      // Label follows cursor with offset
      if (labelRef.current) {
        gsap.set(labelRef.current, {
          x: e.clientX + 16,
          y: e.clientY - 8,
        });
      }

      setVisible(true);
    };

    // ── EVENT DELEGATION for hover states ─────────────────
    // Single listener on document catches ALL elements
    // including ones rendered after mount
    const handleMouseOver = (e) => {
      const el = e.target.closest("[data-cursor]");
      setLabel(el ? (LABEL_MAP[el.getAttribute("data-cursor")] || "") : "");

      // Scale up dot on any interactive element
      const isInteractive =
        e.target.closest("a, button, [data-cursor], [data-magnetic]");
      if (isInteractive) {
        setIsHovered(true);
        gsap.to(dotRef.current, {
          scale: 1.6,
          duration: 0.25,
          ease: "power2.out",
          overwrite: true,
        });
      }
    };

    const handleMouseOut = (e) => {
      const leaving = e.target.closest("a, button, [data-cursor], [data-magnetic]");
      const entering = e.relatedTarget?.closest("a, button, [data-cursor], [data-magnetic]");

      // Only reset if we're leaving an interactive area entirely
      // not just moving between child elements
      if (leaving && !entering) {
        setIsHovered(false);
        setLabel("");
        gsap.to(dotRef.current, {
          scale: 1,
          duration: 0.25,
          ease: "power2.out",
          overwrite: true,
        });
      }
    };

    // ── MAGNETIC EFFECT ───────────────────────────────────
    // Applied via delegation — checks data-magnetic on enter/leave
    const handleMagneticMove = (e) => {
      const el = e.target.closest("[data-magnetic]");
      if (!el) return;

      const rect = el.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top  + rect.height / 2;

      // Soft 25% pull toward center
      const strength = 0.25;
      const targetX  = e.clientX + (centerX - e.clientX) * strength;
      const targetY  = e.clientY + (centerY - e.clientY) * strength;

      // Use set instead of to — avoids tween conflict with quickTo
      gsap.set(dotRef.current, { x: targetX, y: targetY });

      if (labelRef.current) {
        gsap.set(labelRef.current, {
          x: targetX + 16,
          y: targetY - 8,
        });
      }
    };

    // ── VISIBILITY ────────────────────────────────────────
    const handleMouseLeave = () => setVisible(false);
    const handleMouseEnter = () => setVisible(true);

    // Add all listeners to document (event delegation)
    document.addEventListener("mousemove",  handleMouseMove,  { passive: true });
    document.addEventListener("mouseover",  handleMouseOver,  { passive: true });
    document.addEventListener("mouseout",   handleMouseOut,   { passive: true });
    document.addEventListener("mousemove",  handleMagneticMove, { passive: true });
    document.documentElement.addEventListener("mouseleave", handleMouseLeave);
    document.documentElement.addEventListener("mouseenter", handleMouseEnter);

    return () => {
      document.removeEventListener("mousemove",  handleMouseMove);
      document.removeEventListener("mouseover",  handleMouseOver);
      document.removeEventListener("mouseout",   handleMouseOut);
      document.removeEventListener("mousemove",  handleMagneticMove);
      document.documentElement.removeEventListener("mouseleave", handleMouseLeave);
      document.documentElement.removeEventListener("mouseenter", handleMouseEnter);
      document.getElementById("cursor-hide")?.remove();
    };
  }, []);

  return { dotRef, labelRef, label, visible, isHovered, isTouch };
};

export default useCursor;
